SHIPPING MANAGER CURACAO — ANDROID APK SOURCE PROJECT

This ZIP is Android Studio source, NOT a compiled APK.
1. On a computer install Android Studio (free).
2. Extract ZIP and open folder ShippingManagerCuracao_AndroidStudio in Android Studio.
3. Let Gradle sync and install requested Android SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find app-debug.apk in app/build/outputs/apk/debug/.
6. Copy APK to Android phone and install (approve installation from this source if prompted).

This is a WebView wrapper around the existing Shipping Manager app. It stores orders locally in Android WebView storage. It has native PDF/PNG share sheet and Save As document picker, plus screenshot file selection. AI requires internet and a separately deployed Worker configured in the app.

IMPORTANT: Not compiled or tested on an Android device in this environment. Before business use test invoice exports, AI connectivity and saved orders. Existing browser orders do not automatically transfer.
